public class Persegi {
    public static void main(String[] args) {
        int sisi = 5;
        int luas;

        luas = sisi * sisi * sisi;
        System.out.println("Hasil nya adalah = " + luas);

    }
}
