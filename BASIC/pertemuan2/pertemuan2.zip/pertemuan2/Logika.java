public class Logika {
    public static void main(String[] args) {
        boolean a = false;
        boolean b = false;

        // System.out.println(a && b);
        System.out.println(a || b);
    }
}
