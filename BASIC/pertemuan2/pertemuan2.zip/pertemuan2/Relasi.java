public class Relasi {
    public static void main(String[] args) {
        int a = 5;
        int b = 8;

        System.out.println(a!=b);
    }
}
