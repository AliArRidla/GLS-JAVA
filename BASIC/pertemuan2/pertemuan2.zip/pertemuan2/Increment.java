public class Increment {
    public static void main(String[] args) {
        int nilai1 = 5;
        // System.out.println("Nilai dari " + ++nilai1);      
        // System.out.println("Nilai dari " + nilai1++);

        // System.out.println("Nilai dari " + --nilai1);
        System.out.println("Nilai dari " + nilai1--);

        for (int i = 0; i < args.length; i++) {
            
        }
    }
}
